﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{   // A3175
	// Program 4
	// 12/5/17
	// CIS 199-01
	public class Program
	{
		public static void Main(string[] args)
		{
			//creates class objects
			LibraryBook libraryBook1 =
				new LibraryBook("IT", "Stephen King", "Viking Press", 1986, "123");
			LibraryBook libraryBook2 =
				new LibraryBook("The Shining", "Stephen King", "Doubleday", 1977, "237");
			LibraryBook libraryBook3 =
				new LibraryBook("11/22/63", "Stephen King", "Scribner", 2011, "345");
			LibraryBook libraryBook4 =
				new LibraryBook("Pet Sematary", "Stephen King", "Doubleday", 1983, "678");
			LibraryBook libraryBook5 =
				new LibraryBook("Insomnia", "Stephen King", "Viking Press", 1994, "901");

			LibraryBook[] books = new LibraryBook[5]; // creates 5 element array

			//initializes array
			books[0] = libraryBook1;
			books[1] = libraryBook2;
			books[2] = libraryBook3;
			books[3] = libraryBook4;
			books[4] = libraryBook5;

			foreach (LibraryBook currentLibraryBook in books)// processes each element in array
			{
				Console.WriteLine(currentLibraryBook);
				Console.WriteLine();
			}
		}
	}
}
