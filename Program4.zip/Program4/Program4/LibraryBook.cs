﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{	// A3175
	// Program 4
	// 12/5/17
	// CIS 199-01
	class LibraryBook
	{
		// variables for properies
		private string title;
		private string author;
		private string publisher;
		private int copyrightyear;
		private string callnumber;

		public string Title //read-only property for title
		{
			get { return title; }
			set { title = value; }
		}
		public string Author //read-only property for author
		{
			get { return author; }
			set { author = value; }
		}
		public string Publisher //read-only property for publisher
		{
			get { return publisher; }
			set { publisher = value; }
		}
		public int CopyrightYear //read-only property for copyright year
		{
			get { return copyrightyear; }
			set { copyrightyear = value; }
		}
		public string CallNumber // read-only property for call number
		{
			get { return callnumber; }
			set { callnumber = value; }
		}
		bool valid; // variable for ischeckedout
		public void CheckOut() // read-only property for IsCheckedOut
		{
			valid = true;
		}
		public void ReturnToShelf() // read-only property for IsCheckedOut
		{
			valid = false;
		}
		public bool IsCheckedOut //determines if book is checked out
		{
			get { return valid; }
			set
			{
				if (valid == true)
					IsCheckedOut = true;
				else
					IsCheckedOut = false;
			}
		}
		public LibraryBook(string _title, string _author, string _publisher, int _copyrightyear, string _callnumber) // 5 parameter constuctor
		{
			Title = _title;
			Author = _author;
			Publisher = _publisher;
			CopyrightYear = _copyrightyear;
			CallNumber = _callnumber;
		}
		public override string ToString() // return string for LibraryBook, using properties
		{
			return $"{Title}{Environment.NewLine}" +
				$"{Author}{Environment.NewLine}" +
				$"{Publisher}{Environment.NewLine}" +
				$"{CopyrightYear}{Environment.NewLine}" +
				$"{CallNumber}{ Environment.NewLine}" +
				$"{IsCheckedOut}";
		}
	}
}

