﻿namespace Program2
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.enterName = new System.Windows.Forms.TextBox();
			this.nameLabel = new System.Windows.Forms.Label();
			this.fBut = new System.Windows.Forms.RadioButton();
			this.soBut = new System.Windows.Forms.RadioButton();
			this.jBut = new System.Windows.Forms.RadioButton();
			this.sBut = new System.Windows.Forms.RadioButton();
			this.outputLabel = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// enterName
			// 
			this.enterName.Location = new System.Drawing.Point(136, 71);
			this.enterName.Name = "enterName";
			this.enterName.Size = new System.Drawing.Size(100, 20);
			this.enterName.TabIndex = 0;
			// 
			// nameLabel
			// 
			this.nameLabel.AutoSize = true;
			this.nameLabel.Location = new System.Drawing.Point(32, 74);
			this.nameLabel.Name = "nameLabel";
			this.nameLabel.Size = new System.Drawing.Size(89, 13);
			this.nameLabel.TabIndex = 1;
			this.nameLabel.Text = "Enter Last Name:";
			// 
			// fBut
			// 
			this.fBut.AutoSize = true;
			this.fBut.Location = new System.Drawing.Point(115, 97);
			this.fBut.Name = "fBut";
			this.fBut.Size = new System.Drawing.Size(71, 17);
			this.fBut.TabIndex = 2;
			this.fBut.TabStop = true;
			this.fBut.Text = "Freshman";
			this.fBut.UseVisualStyleBackColor = true;
			// 
			// soBut
			// 
			this.soBut.AutoSize = true;
			this.soBut.Location = new System.Drawing.Point(115, 120);
			this.soBut.Name = "soBut";
			this.soBut.Size = new System.Drawing.Size(79, 17);
			this.soBut.TabIndex = 3;
			this.soBut.TabStop = true;
			this.soBut.Text = "Sophomore";
			this.soBut.UseVisualStyleBackColor = true;
			// 
			// jBut
			// 
			this.jBut.AutoSize = true;
			this.jBut.Location = new System.Drawing.Point(115, 143);
			this.jBut.Name = "jBut";
			this.jBut.Size = new System.Drawing.Size(53, 17);
			this.jBut.TabIndex = 4;
			this.jBut.TabStop = true;
			this.jBut.Text = "Junior";
			this.jBut.UseVisualStyleBackColor = true;
			// 
			// sBut
			// 
			this.sBut.AutoSize = true;
			this.sBut.Location = new System.Drawing.Point(113, 166);
			this.sBut.Name = "sBut";
			this.sBut.Size = new System.Drawing.Size(55, 17);
			this.sBut.TabIndex = 5;
			this.sBut.TabStop = true;
			this.sBut.Text = "Senior";
			this.sBut.UseVisualStyleBackColor = true;
			// 
			// outputLabel
			// 
			this.outputLabel.Location = new System.Drawing.Point(79, 215);
			this.outputLabel.Name = "outputLabel";
			this.outputLabel.ReadOnly = true;
			this.outputLabel.Size = new System.Drawing.Size(100, 20);
			this.outputLabel.TabIndex = 6;
			this.outputLabel.TextChanged += new System.EventHandler(this.outputLabel_TextChanged);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 261);
			this.Controls.Add(this.outputLabel);
			this.Controls.Add(this.sBut);
			this.Controls.Add(this.jBut);
			this.Controls.Add(this.soBut);
			this.Controls.Add(this.fBut);
			this.Controls.Add(this.nameLabel);
			this.Controls.Add(this.enterName);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox enterName;
		private System.Windows.Forms.Label nameLabel;
		private System.Windows.Forms.RadioButton fBut;
		private System.Windows.Forms.RadioButton soBut;
		private System.Windows.Forms.RadioButton jBut;
		private System.Windows.Forms.RadioButton sBut;
		private System.Windows.Forms.TextBox outputLabel;
	}
}

