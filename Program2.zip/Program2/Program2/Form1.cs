﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{   //A3175
	//10/22/17
	//Program2
	//CIS199-01
	//Hep get schedule times

	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
			
			}

		private void outputLabel_TextChanged(object sender, EventArgs e)
			{
				const string TIME1 = "8:30";// constant for time 1
				const string TIME2 = "10:00";// constant for time 2
				const string TIME3 = "11:30";// constant for time 3
				const string TIME4 = "2:00";//constant for time 4
				const string TIME5 = "4:00";// constant for time 5
				const string DAY1 = "Nov.3RD";// constant for date 1
				const string DAY2 = "Nov.6TH";// constant for date 2
				const string DAY3 = "Nov.7TH";// constant for date 3
				const string DAY4 = "Nov.8TH";// constant for date 4
				const string DAY5 = "Nov.9TH";// constant for date 5
				const string DAY6 = "Nov.10TH";// constant fot date 6
				char FLLN;// first letter last name abr


				if (char.TryParse(enterName.Text, out FLLN))// parses text
				{
					FLLN = char.ToLower(FLLN);//code to convert uppercase to lower

					if (fBut.Checked)// freshman button checked
					{
						if (FLLN >= 't' && FLLN <= 'v')// letters t-v
						{
							outputLabel.Text = DAY5 + " " + TIME1;// output
						}
						if (FLLN >= 'w' && FLLN <= 'z')// letters w-z
						{
							outputLabel.Text = DAY5 + " " + TIME2;//output 
						}
						if (FLLN >= 'a' && FLLN <= 'b')// letters a-b
						{
							outputLabel.Text = DAY5 + " " + TIME3;// output
						}
						if (FLLN >= 'c' && FLLN <= 'd')// letters c-d
						{
							outputLabel.Text = DAY5 + " " + TIME4;// output
						}
						if (FLLN >= 'e' && FLLN <= 'f')//letters e-f
						{
							outputLabel.Text = DAY5 + " " + TIME5;// output
						}
						if (FLLN >= 'g' && FLLN <= 'i')//letters g-i
						{
							outputLabel.Text = DAY6 + " " + TIME1;//output
						}
						if (FLLN >= 'j' && FLLN <= 'l')//letters j-l
						{
							outputLabel.Text = DAY6 + " " + TIME2;// output
						}
						if (FLLN >= 'm' && FLLN <= 'o')//letters m-o
						{
							outputLabel.Text = DAY6 + " " + TIME3;// output
						}
						if (FLLN >= 'p' && FLLN <= 'q')//letters p-q
						{
							outputLabel.Text = DAY6 + " " + TIME4;//output
						}
						if (FLLN >= 'r' && FLLN <= 's')//letters r-s
						{
							outputLabel.Text = DAY6 + " " + TIME5;//output
						}
					}

					
					if (soBut.Checked)//sophomore button checked
					{
						if (FLLN >= 't' && FLLN <= 'v')//letters t-v
						{
							outputLabel.Text = DAY3 + " " + TIME1;//output
						}
						if (FLLN >= 'w' && FLLN <= 'z')//letters w-z
						{
							outputLabel.Text = DAY3 + " " + TIME2;//output
						}
						if (FLLN >= 'a' && FLLN <= 'b')// letters a-b
						{
							outputLabel.Text = DAY3 + " " + TIME3;//output
						}
						if (FLLN >= 'c' && FLLN <= 'd')//letters c-d
						{
							outputLabel.Text = DAY3 + " " + TIME4;//output
						}
						if (FLLN >= 'e' && FLLN <= 'f')//letters e-f
						{
							outputLabel.Text = DAY3 + " " + TIME5;//output
						}
						if (FLLN >= 'g' && FLLN <= 'i')//letters g-i
						{
							outputLabel.Text = DAY4 + " " + TIME1;//output
						}
						if (FLLN >= 'j' && FLLN <= 'l')//letters j-l
						{
							outputLabel.Text = DAY4 + " " + TIME2;//output
						}
						if (FLLN >= 'm' && FLLN <= 'o')//letters m-o
						{
							outputLabel.Text = DAY4 + " " + TIME3;//output
						}
						if (FLLN >= 'p' && FLLN <= 'q')//letters p-q
						{
							outputLabel.Text = DAY4 + " " + TIME4;//output
						}
						if (FLLN >= 'r' && FLLN <= 's')//letters r-s
						{
							outputLabel.Text = DAY4 + " " + TIME5;//output
						}
					}

					if (jBut.Checked)//junior button checked
					{
						if (FLLN >= 't' && FLLN <= 'z')//letters t-z
						{
							outputLabel.Text = DAY2 + " " + TIME1;//output
						}
						if (FLLN >= 'a' && FLLN <= 'd')//letters a-d
						{
							outputLabel.Text = DAY2 + " " + TIME2;//output
						}
						if (FLLN >= 'e' && FLLN <= 'i')//letters e-i
						{
							outputLabel.Text = DAY2 + " " + TIME3;//output
						}
						if (FLLN >= 'j' && FLLN <= 'o')//letters j-o
						{
							outputLabel.Text = DAY2 + " " + TIME4;//output
						}
						if (FLLN >= 'p' && FLLN <= 's')//letters p-s
						{
							outputLabel.Text = DAY2 + " " + TIME5;//output
						}

					}

					if (sBut.Checked)//senior button checked
					{
						if (FLLN >= 't' && FLLN <= 'z')//letters t-z
						{
							outputLabel.Text = DAY1 + " " + TIME1;//output
						}
						if (FLLN >= 'a' && FLLN <= 'd')//lettrers a-d
						{
							outputLabel.Text = DAY1 + " " + TIME2;//output
						}
						if (FLLN >= 'e' && FLLN <= 'i')//letters e-i
						{
							outputLabel.Text = DAY1 + " " + TIME3;//output
						}
						if (FLLN >= 'j' && FLLN <= 'o')//letters j-o
						{
							outputLabel.Text = DAY1 + " " + TIME4;//output
						}
						if (FLLN >= 'p' && FLLN <= 's')//letters p-s
						{
							outputLabel.Text = DAY1 + " " + TIME5;//output
						}
					}
				}
			}

		
		}

		}
	

