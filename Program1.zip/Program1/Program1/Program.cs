﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{   // A3175
    // program 1
    // 9/26/17
    // CIS 199-01
    class Program
    {
        static void Main(string[] args)
        {
            double lengthWalls, heightWalls, numDoors, numWind, totalSqFeet, amtOfPaint;// defines all doubles
            const int doorSub = 20, windSub = 15, sqFeetPerCoat = 350;// defines all const int
            int numCoats, gallonsToBuy;// defines all int

            Console.WriteLine("Welcome to the Handy-Dandy Paint Estimator");// welcomes user

            Console.WriteLine("Enter the total length of walls (in feet):");// tells user to enter length of walls
            lengthWalls = double.Parse(Console.ReadLine());// user's input of length of walls
            Console.WriteLine("Enter the total height of the walls (in feet):");// tells the user to input height of walls
            heightWalls = double.Parse(Console.ReadLine());// user's input of height of walls
            Console.WriteLine("Enter the number of doors (non-neg int):");// tells user to input number of doors
            numDoors = double.Parse(Console.ReadLine());// user's input of number of doors
            Console.WriteLine("Enter the number of windows (non-neg int):");// tells user to input number of windows
            numWind = double.Parse(Console.ReadLine());// user's input of number of windows
            Console.WriteLine("Enter the number of coats of paint (non-neg int):");// tells user to input number of coats
            numCoats = int.Parse(Console.ReadLine());// user's input of number of coats

            totalSqFeet = lengthWalls * heightWalls - numDoors * doorSub - numWind * windSub;// calculation of total square feet
            amtOfPaint = totalSqFeet * numCoats / sqFeetPerCoat;// calculation of the actual amount of paint
            gallonsToBuy = (int)Math.Ceiling(amtOfPaint);// calculation of the rounded amount of paint

            Console.WriteLine("You need a minimum of {0:F1} gallons of paint", amtOfPaint);// shows the user the actual calculation of paint
            Console.WriteLine("You'll need to buy {0} gallons, though", gallonsToBuy);// shows the user the rounded calculation of paint
        }
    }
}
